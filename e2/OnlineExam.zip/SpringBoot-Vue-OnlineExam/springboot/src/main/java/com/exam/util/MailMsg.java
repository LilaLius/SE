package com.exam.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.time.Duration;

/**
 * 邮箱验证码发送工具类
 */
@Component
public class MailMsg {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    /**
     * 发送验证码邮件并缓存验证码到Redis
     *
     * @param email 接收验证码的邮箱
     * @return 发送成功返回true，异常时抛出MessagingException
     * @throws MessagingException 邮件发送异常
     */
    public boolean sendVerificationCode(String email) throws MessagingException {
        // 生成6位随机验证码
        String code = CodeGeneratorUtil.generateNumericCode(6);

        // 创建邮件消息
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

        // 邮件内容（html格式）
        String content = "<p style='color:blue;'>三秦锅，你在搞什么飞机！你的验证码为：" + code + "（有效期1分钟）</p>";
        helper.setText(content, true);

        helper.setSubject("FlowerPotNet验证码");
        helper.setTo(email);
        helper.setFrom("2463252763@qq.com"); // 发件邮箱，建议用配置读取

        // 将验证码存入Redis，设置过期时间1分钟
        redisTemplate.opsForValue().set(email, code, Duration.ofMinutes(1));

        // 发送邮件
        mailSender.send(mimeMessage);

        return true;
    }
}
