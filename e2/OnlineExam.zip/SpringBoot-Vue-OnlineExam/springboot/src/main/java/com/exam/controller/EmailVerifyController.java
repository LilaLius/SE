package com.exam.controller;

import com.exam.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class EmailVerifyController {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @PostMapping("/verifyEmailCode")
    public Result<?> verifyEmailCode(@RequestBody VerifyCodeRequest request) {
        String redisKey = "emailCode:" + request.getEmail();
        String cachedCode = redisTemplate.opsForValue().get(redisKey);

        if (cachedCode == null) {
            return Result.error("验证码已过期，请重新获取");
        }

        if (!cachedCode.equals(request.getCode())) {
            return Result.error("验证码错误");
        }

        // 验证成功后，可以选择删除验证码，避免重复使用
        redisTemplate.delete(redisKey);

        return Result.success("验证码验证成功");
    }
}

class VerifyCodeRequest {
    private String email;
    private String code;

    // Getter and Setter
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
}
