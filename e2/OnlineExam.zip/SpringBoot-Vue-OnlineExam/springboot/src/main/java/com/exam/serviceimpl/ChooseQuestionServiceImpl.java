package com.exam.serviceimpl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.entity.ChooseQuestion;
import com.exam.mapper.ChooseQuestionMapper;
import com.exam.service.ChooseQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChooseQuestionServiceImpl implements ChooseQuestionService {

    @Autowired
    private ChooseQuestionMapper chooseQuestionMapper;
    @Override
    public List<ChooseQuestion> findByIdAndType(Integer PaperId) {
        return chooseQuestionMapper.findByIdAndType(PaperId);
    }

    @Override
    public IPage<ChooseQuestion> findAll(Page<ChooseQuestion> page) {
        return chooseQuestionMapper.findAll(page);
    }

    @Override
    public ChooseQuestion findOnlyQuestionId() {
        return chooseQuestionMapper.findOnlyQuestionId();
    }

    @Override
    public int add(ChooseQuestion multiQuestion) {
        return chooseQuestionMapper.add(multiQuestion);
    }

    @Override
    public List<Integer> findBySubject(String subject, Integer pageNo) {
        return chooseQuestionMapper.findBySubject(subject,pageNo);
    }
}
