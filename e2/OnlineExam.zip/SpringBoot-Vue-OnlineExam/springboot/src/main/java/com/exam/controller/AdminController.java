package com.exam.controller;

import com.exam.entity.Admin;
import com.exam.entity.ApiResult;
import com.exam.serviceimpl.AdminServiceImpl;
import com.exam.util.ApiResultHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class AdminController {

    @Autowired
    private AdminServiceImpl adminService;

    @GetMapping("/admins")
    public ApiResult findAll(){
        System.out.println("查询全部");
        ApiResult apiResult;
        apiResult = ApiResultHandler.buildApiResult(200,"请求成功！",adminService.findAll());
        return apiResult;
    }

    @GetMapping("/admin/{adminId}")
    public ApiResult findById(@PathVariable("adminId") Integer adminId){
        System.out.println("根据ID查找");
        Admin res = adminService.findById(adminId);
        if(res == null){
            return ApiResultHandler.buildApiResult(10000,"管理员ID不存在",null);
        }
        return ApiResultHandler.buildApiResult(200,"请求成功！",res);
    }

    @DeleteMapping("/admin/{adminId}")
    public ApiResult deleteById(@PathVariable("adminId") Integer adminId){
        int res = adminService.deleteById(adminId);
        return ApiResultHandler.buildApiResult(200,"删除成功",res);
    }

    @PutMapping("/admin/{adminId}")
    public ApiResult update(@PathVariable("adminId") Integer adminId,@RequestBody Admin admin){
        int res = adminService.update(admin);
        System.out.print("更新执行操作---");
        return ApiResultHandler.buildApiResult(200,"更新成功",res);
    }

    @PostMapping("/admin")
    public ApiResult add(@RequestBody Admin admin){
        int res = adminService.add(admin);
        if (res ==1) {
            return ApiResultHandler.buildApiResult(200, "添加成功", res);
        } else {
            return  ApiResultHandler.buildApiResult(400,"添加失败",res);
        }
    }
}
