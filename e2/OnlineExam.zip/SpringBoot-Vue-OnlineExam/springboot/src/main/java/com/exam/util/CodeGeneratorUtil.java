package com.exam.util;

import java.security.SecureRandom;

/**
 * 生成验证码工具类
 */
public class CodeGeneratorUtil {

    private static final String CODE_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private static final SecureRandom random = new SecureRandom();

    /**
     * 生成指定长度的数字验证码（默认纯数字）
     * @param length 验证码长度
     * @return 纯数字验证码字符串
     */
    public static String generateNumericCode(int length) {
        StringBuilder sb = new StringBuilder(length);
        for(int i = 0; i < length; i++) {
            int index = random.nextInt(10); // 0-9数字
            sb.append(CODE_CHARS.charAt(index));
        }
        return sb.toString();
    }

    /**
     * 生成指定长度的数字+字母混合验证码
     * @param length 验证码长度
     * @return 字母数字混合验证码
     */
    public static String generateAlphanumericCode(int length) {
        StringBuilder sb = new StringBuilder(length);
        for(int i = 0; i < length; i++) {
            int index = random.nextInt(CODE_CHARS.length());
            sb.append(CODE_CHARS.charAt(index));
        }
        return sb.toString();
    }
}
