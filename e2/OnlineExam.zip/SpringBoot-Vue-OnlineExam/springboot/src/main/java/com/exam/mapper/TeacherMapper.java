package com.exam.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.entity.Teacher;
import org.apache.ibatis.annotations.*;

import java.util.List;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

@Mapper
public interface TeacherMapper extends BaseMapper<Teacher> {

    @Select("select * from teacher")
    IPage<Teacher>  findAll(Page page);

    @Select("select * from teacher")
    List<Teacher> findAll();

    @Select("select teacherName,institute,sex,tel,email,pwd,cardId,type,role from teacher where teacherId = #{teacherId}")
    List<Teacher> findById(Integer teacherId);

    @Delete("delete from teacher where teacherId = #{teacherId}")
    int deleteById(Integer teacherId);

    @Update("update teacher set teacherName = #{teacherName},sex = #{sex}," +
            "tel = #{tel}, email = #{email},pwd = #{pwd},cardId = #{cardId}," +
            "role = #{role},institute = #{institute},type = #{type} where teacherId = #{teacherId}")
    int update(Teacher teacher);

    @Options(useGeneratedKeys = true,keyProperty = "teacherId")
    @Insert("insert into teacher(teacherName,sex,tel,email,pwd,cardId,role,type,institute) " +
            "values(#{teacherName},#{sex},#{tel},#{email},#{pwd},#{cardId},#{role},#{type},#{institute})")
    int add(Teacher teacher);
}

