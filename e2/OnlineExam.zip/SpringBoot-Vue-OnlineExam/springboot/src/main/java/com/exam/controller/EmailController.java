package com.exam.controller;

import com.exam.service.EmailService;
import com.exam.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @PostMapping("/sendEmailCode")
    public Result<?> sendEmailCode(@RequestBody EmailRequest request) {
        boolean sent = emailService.sendVerificationCode(request.getEmail());
        if (sent) {
            return Result.success("验证码发送成功");
        } else {
            return Result.error("验证码发送失败");
        }
    }
}

class EmailRequest {
    private String email;
    // getter 和 setter
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
