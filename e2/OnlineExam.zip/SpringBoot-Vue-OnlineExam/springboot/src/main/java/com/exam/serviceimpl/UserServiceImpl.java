package com.exam.serviceimpl;

import com.exam.entity.User;
import com.exam.mapper.UserMapper;
import com.exam.service.UserService;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserMapper userMapper;

    @Override
    public User findByEmail(String email) {
        return userMapper.selectByEmail(email);
    }

    @Override
    public boolean updatePasswordByEmail(String email, String newPassword) {
        // 建议加密密码，例如用 BCrypt
        String encodedPassword = new BCryptPasswordEncoder().encode(newPassword);
        return userMapper.updatePasswordByEmail(email, encodedPassword) > 0;
    }
}

