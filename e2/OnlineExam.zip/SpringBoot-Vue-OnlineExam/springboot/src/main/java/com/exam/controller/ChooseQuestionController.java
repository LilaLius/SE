package com.exam.controller;

import com.exam.entity.ApiResult;
import com.exam.entity.ChooseQuestion;
import com.exam.serviceimpl.ChooseQuestionServiceImpl;
import com.exam.util.ApiResultHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChooseQuestionController {

    @Autowired
    private ChooseQuestionServiceImpl chooseQuestionService;

    @GetMapping("/chooseQuestionId")
    public ApiResult findOnlyQuestion() {
        ChooseQuestion res = chooseQuestionService.findOnlyQuestionId();
        return ApiResultHandler.buildApiResult(200,"查询成功",res);
    }

    @PostMapping("/ChooseQuestion")
    public ApiResult add(@RequestBody ChooseQuestion chooseQuestion) {
        int res = chooseQuestionService.add(chooseQuestion);
        if (res != 0) {

            return ApiResultHandler.buildApiResult(200,"添加成功",res);
        }
        return ApiResultHandler.buildApiResult(400,"添加失败",res);
    }
}
