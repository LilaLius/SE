package com.exam.controller;

import com.exam.dto.ResetPasswordRequest;
import com.exam.entity.User;
import com.exam.service.UserService;
import com.exam.util.Result;
import javax.annotation.Resource;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class AuthController {

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource
    private UserService userService;

    @PostMapping("/resetPassword")
    public Result<?> resetPassword(@RequestBody ResetPasswordRequest request) {
        String redisKey = "email:code:" + request.getEmail();
        String realCode = stringRedisTemplate.opsForValue().get(redisKey);

        if (realCode == null) {
            return Result.error("验证码已过期，请重新获取");
        }

        if (!realCode.equals(request.getCode())) {
            return Result.error("验证码错误");
        }

        User user = userService.findByEmail(request.getEmail());
        if (user == null) {
            return Result.error("邮箱未注册");
        }

        boolean success = userService.updatePasswordByEmail(request.getEmail(), request.getNewPassword());

        if (success) {
            stringRedisTemplate.delete(redisKey); // 用完后删除验证码
            return Result.success("密码重置成功");
        } else {
            return Result.error("密码重置失败");
        }
    }
}
