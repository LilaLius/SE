package com.exam.service;

import com.exam.entity.User;

public interface UserService {
    User findByEmail(String email);
    boolean updatePasswordByEmail(String email, String newPassword);
}
