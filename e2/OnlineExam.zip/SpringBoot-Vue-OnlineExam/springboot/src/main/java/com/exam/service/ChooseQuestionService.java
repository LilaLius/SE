package com.exam.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.entity.ChooseQuestion;

import java.util.List;

public interface ChooseQuestionService {

    List<ChooseQuestion> findByIdAndType(Integer PaperId);

    IPage<ChooseQuestion> findAll(Page<ChooseQuestion> page);

    ChooseQuestion findOnlyQuestionId();

    int add(ChooseQuestion multiQuestion);

    List<Integer> findBySubject(String subject,Integer pageNo);
}
