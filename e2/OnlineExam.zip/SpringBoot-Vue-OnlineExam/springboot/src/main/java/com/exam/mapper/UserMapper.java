package com.exam.mapper;

import com.exam.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Param;


@Mapper
public interface UserMapper {
    User selectByEmail(String email);

    @Update("UPDATE user SET password = #{password} WHERE email = #{email}")
    int updatePasswordByEmail(@Param("email") String email, @Param("password") String password);
}

