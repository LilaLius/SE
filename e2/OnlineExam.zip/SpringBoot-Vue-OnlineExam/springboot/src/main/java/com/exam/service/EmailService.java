package com.exam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    // 这里可以把验证码存到Redis，方便后续校验
    public boolean sendVerificationCode(String toEmail) {
        try {
            String code = generateCode(6); // 生成6位验证码

            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(toEmail);
            message.setSubject("验证码");
            message.setText("您的验证码是：" + code + "，有效时间5分钟。");

            mailSender.send(message);

            // 这里可以保存code到Redis，和toEmail关联

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private String generateCode(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for(int i=0; i<length; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
}

