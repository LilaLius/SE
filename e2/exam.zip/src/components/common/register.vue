<template>
    <div class="register-container">
      <h2>注册账号</h2>
      <form @submit.prevent="submitForm">
        <div>
          <label>用户名：</label>
          <input v-model="form.username" required />
        </div>
        <div>
          <label>邮箱：</label>
          <input v-model="form.email" type="email" required />
        </div>
        <div>
          <label>验证码：</label>
          <input v-model="form.verificationCode" required />
          <button type="button" @click="sendVerificationCode" :disabled="codeSending || countdown > 0">
            {{ countdown > 0 ? countdown + '秒后重发' : '发送验证码' }}
          </button>
        </div>
        <button type="submit">注册</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        form: {
          username: '',
          email: '',
          verificationCode: ''
        },
        codeSending: false,
        countdown: 0,
        countdownTimer: null
      };
    },
    methods: {
      isEmailValid(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
      },
      sendVerificationCode() {
        if (!this.form.email) {
          alert("请输入邮箱");
          return;
        }
        if (!this.isEmailValid(this.form.email)) {
          alert("请输入有效的邮箱地址");
          return;
        }
        this.codeSending = true;
        this.$axios.post('/api/sendEmailCode', { email: this.form.email })
          .then(() => {
            alert("验证码已发送，请查收邮箱");
            this.countdown = 60;
            this.countdownTimer = setInterval(() => {
              if (this.countdown > 0) {
                this.countdown--;
              } else {
                clearInterval(this.countdownTimer);
                this.codeSending = false;
              }
            }, 1000);
          })
          .catch(() => {
            alert("发送失败，请稍后重试");
            this.codeSending = false;
          });
      },
      submitForm() {
        this.$axios.post('/api/register', this.form)
          .then(() => {
            alert("注册成功");
            this.form.username = '';
            this.form.email = '';
            this.form.verificationCode = '';
            this.$router.push('/login');
          })
          .catch(err => {
            alert((err.response && err.response.data && err.response.data.message) || "注册失败");
          });
      }
    },
    beforeDestroy() {
      if (this.countdownTimer) clearInterval(this.countdownTimer);
    }
  };
  </script>
  