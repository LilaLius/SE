<template>
  <div id="reset-password">
    <div class="bg"></div>
    <el-row class="main-container">
      <el-col :lg="8" :xs="16" :md="10" :span="10">
        <div class="top">
          <i class="iconfont icon-kaoshi"></i><span class="title">找回密码</span>
        </div>
        <div class="bottom">
          <el-steps :active="step" finish-status="success" simple>
            <el-step title="身份验证" />
            <el-step title="重置密码" />
            <el-step title="完成" />
          </el-steps>

          <!-- Step 0: 邮箱+验证码 -->
          <div class="container" v-if="step === 0">
            <el-form :model="emailForm" :rules="rules" ref="emailFormRef" label-width="80px">
              <el-form-item label="邮箱" prop="email">
                <el-input v-model="emailForm.email" placeholder="请输入注册邮箱"></el-input>
              </el-form-item>
              <el-form-item label="验证码" prop="code">
                <el-input v-model="emailForm.code" placeholder="请输入验证码" style="width: 200px;"></el-input>
                <el-button @click="sendCode" :disabled="countdown > 0" type="primary" size="small" style="margin-left: 10px;">
                  {{ countdown > 0 ? `${countdown}s后重试` : '发送验证码' }}
                </el-button>
              </el-form-item>
              <el-button type="primary" @click="verifyCode">下一步</el-button>
            </el-form>
          </div>

          <!-- Step 1: 重置密码 -->
          <div class="container" v-else-if="step === 1">
            <el-form :model="passwordForm" label-width="80px">
              <el-form-item label="新密码">
                <el-input v-model="passwordForm.password" type="password" placeholder="请输入新密码"></el-input>
              </el-form-item>
              <el-form-item label="确认密码">
                <el-input v-model="passwordForm.confirm" type="password" placeholder="请再次输入新密码"></el-input>
              </el-form-item>
              <el-button type="primary" @click="resetPassword">重置密码</el-button>
            </el-form>
          </div>

          <!-- Step 2: 完成 -->
          <div class="container" v-else>
            <p class="title">密码重置成功！</p>
            <el-button type="primary" @click="$router.push('/login')">返回登录</el-button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  name: 'ResetPassword',
  data() {
    return {
      step: 0,
      countdown: 0,
      emailForm: {
        email: '',
        code: ''
      },
      passwordForm: {
        password: '',
        confirm: ''
      },
      rules: {
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { type: 'email', message: '邮箱格式不正确', trigger: ['blur', 'change'] }
        ],
        code: [
          { required: true, message: '请输入验证码', trigger: 'blur' }
        ]
      }
    };
  },
  methods: {
    sendCode() {
      this.$refs.emailFormRef.validateField('email', (valid) => {
        if (!valid) return;
        this.$axios.post('/api/sendEmailCode', { email: this.emailForm.email })
          .then(res => {
            if (res.data.success) {
              this.$message.success("验证码发送成功");
              this.countdown = 60;
              const timer = setInterval(() => {
                this.countdown--;
                if (this.countdown <= 0) clearInterval(timer);
              }, 1000);
            } else {
              this.$message.error(res.data.message || "验证码发送失败");
            }
          })
          .catch(err => {
            console.error(err);
            this.$message.error("请求失败，请检查网络或后端接口");
          });
      });
    },
    verifyCode() {
      this.$refs.emailFormRef.validate((valid) => {
        if (!valid) return;
        this.$axios.post('/api/verifyEmailCode', this.emailForm)
          .then(res => {
            if (res.data.success) {
              this.step = 1;
              this.$message.success("身份验证成功");
            } else {
              this.$message.error(res.data.message || "验证码错误");
            }
          })
          .catch(err => {
            console.error(err);
            this.$message.error("验证失败");
          });
      });
    },
    resetPassword() {
      const { password, confirm } = this.passwordForm;
      if (!password || !confirm) {
        this.$message.error("请填写所有密码字段");
        return;
      }
      if (password !== confirm) {
        this.$message.error("两次输入的密码不一致");
        return;
      }
      this.$axios.post('/api/resetPassword', {
        email: this.emailForm.email,
        newPassword: password
      }).then(res => {
        if (res.data.success) {
          this.$message.success("密码重置成功");
          this.step = 2;
        } else {
          this.$message.error(res.data.message || "密码重置失败");
        }
      }).catch(err => {
        console.error(err);
        this.$message.error("密码重置请求失败");
      });
    }
  }
};
</script>

<style scoped>
#reset-password .bg {
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background: url('../../assets/img/loginbg.jpg') center top / cover no-repeat;
}
#reset-password .main-container {
  display: flex;
  justify-content: center;
  align-items: center;
}
#reset-password .top {
  margin-top: 100px;
  font-size: 30px;
  color: #04468b;
  display: flex;
  justify-content: center;
}
#reset-password .title {
  text-align: center;
  font-size: 24px;
  margin: 20px 0;
}
.container {
  background-color: #ffffff;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  margin-top: 30px;
}
.iconfont {
  font-size: 60px;        /* 放大图标 */
  color: #04468b;         /* 保持与文字一致的颜色 */
  margin-right: 10px;     /* 图标与文字之间空隙 */
  vertical-align: middle; /* 图标垂直居中 */
}
</style>
