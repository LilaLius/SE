module.exports = {
    devServer: {
      port: 8089, // 你的前端端口，跟你启动时的端口保持一致
      proxy: {
        '/api': {
          target: 'http://localhost:8080', // 你的后端Spring Boot服务端口
          changeOrigin: true,
          pathRewrite: { '^/api': '' }, // 如果后端接口没有 /api 前缀就去掉它
        }
      }
    }
  };
  